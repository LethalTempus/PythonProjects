class terminal_symbol:


    def __init__(self, symbol):
        self.terminal = symbol


    def generate(self):
        return self.terminal